package calculatorpackage;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class mainMenu implements ActionListener {

	private static final int WIDTH = 480;
	private static final int HEIGHT = 720;
	private JLabel titleLabel;
	private JButton calcBtn, game1Btn, game2Btn, exitBtn;

	public mainMenu() {

		titleLabel = new JLabel("32-Bit IEEE Calculator �");

		JPanel titlePanel = new JPanel();
		titlePanel.setPreferredSize(new Dimension(200, 57));
		titleLabel.setFont(new Font(titleLabel.getFont().getName(), titleLabel.getFont().getStyle(), 36));
		titlePanel.add(titleLabel);

		calcBtn = new JButton("Open Calculator");
		calcBtn.addActionListener(this);
		game1Btn = new JButton("Play 2048");
		game1Btn.addActionListener(this);
		game2Btn = new JButton("Play Snake");
		game2Btn.addActionListener(this);
		exitBtn = new JButton("Exit Application");
		exitBtn.addActionListener(this);

		JFrame mainFrame = new JFrame();
		mainFrame.setTitle("Calculator");
		mainFrame.setSize(WIDTH, HEIGHT);
		JPanel btnPanel = new JPanel(new GridLayout(4, 1));
		btnPanel.add(calcBtn);
		btnPanel.add(game1Btn);
		btnPanel.add(game2Btn);
		btnPanel.add(exitBtn);

		mainFrame.setLayout(new BorderLayout());
		mainFrame.add(titlePanel, BorderLayout.NORTH);
		mainFrame.add(btnPanel, BorderLayout.CENTER);

		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == calcBtn) {
			new Calculator();
		}
		if (e.getSource() == game1Btn) {
			new Game2048();
		}
		if (e.getSource() == game2Btn) {
			new GameSnake();
		}
		if (e.getSource() == exitBtn) {
			System.exit(0);
		}

	}

	public static void main(String[] args) {
		new mainMenu();
	}
}
