/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;
import java.awt.Point;
import java.util.Random;
/**
 *
 * @author Simon
 */
public class Treat {
    
    static Random rand = new Random();
    
    public Treat(int numSystem, Point p){
        switch (numSystem){
            case 0:
                binTreat(p);
            case 1:
                hexTreat(p);
            case 2:
                octTreat(p);
        }
    }
    
    public String binTreat(Point p){
        
    }
    public String hexTreat(Point p){
        
    }
    public String octTreat(Point p){
        
    }
    
}
